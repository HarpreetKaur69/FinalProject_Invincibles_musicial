$(function(){
    $("button").on('click',()=>{
        $(".audio").attr('src','assests/mp3/Jim-Yosef-Lights-NCS-Release.mp3');
    })
})